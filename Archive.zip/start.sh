#!/bin/bash

# Bill's Aeroponics - Startup Script
echo "🌱 Starting Bill's Aeroponics Smart Watering System..."

# Check if running on Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/cpuinfo 2>/dev/null; then
    echo "⚠️  Warning: This script is designed for Raspberry Pi"
    echo "   Some GPIO features may not work on other systems"
fi

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Error: Python 3 is not installed"
    echo "   Please install Python 3 first: sudo apt update && sudo apt install python3 python3-pip"
    exit 1
fi

# Check if required packages are installed
echo "📦 Checking dependencies..."
if ! python3 -c "import flask" 2>/dev/null; then
    echo "📥 Installing Python dependencies..."
    pip3 install -r requirements.txt
fi

# Set GPIO permissions (if on Raspberry Pi)
if grep -q "Raspberry Pi" /proc/cpuinfo 2>/dev/null; then
    echo "🔧 Setting up GPIO permissions..."
    sudo usermod -a -G gpio $USER 2>/dev/null || true
fi

# Create schedule.json if it doesn't exist
if [ ! -f "schedule.json" ]; then
    echo "📝 Creating initial schedule file..."
    echo "[]" > schedule.json
fi

# Check if port 5000 is available
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "⚠️  Warning: Port 5000 is already in use"
    echo "   The application may not start properly"
    echo "   Consider stopping other services or changing the port"
fi

echo "🚀 Starting the web application..."
echo "   Web interface will be available at: http://$(hostname -I | awk '{print $1}'):5000"
echo "   Press Ctrl+C to stop the application"
echo ""

# Run the application
python3 app.py 