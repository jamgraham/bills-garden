#!/usr/bin/env python3
"""
GPIO Test Script for Bill's Aeroponics
This script tests the GPIO pin functionality without running the full web application.
"""

import RPi.GPIO as GPIO
import time
import sys

# GPIO Configuration
PIN_3V = 18  # GPIO18 for 3V control

def setup_gpio():
    """Initialize GPIO settings"""
    try:
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(PIN_3V, GPIO.OUT)
        GPIO.output(PIN_3V, GPIO.LOW)
        print(f"✅ GPIO {PIN_3V} initialized successfully")
        return True
    except Exception as e:
        print(f"❌ Failed to initialize GPIO: {e}")
        return False

def test_pin_activation(duration=3):
    """Test pin activation for specified duration"""
    try:
        print(f"🔌 Activating GPIO {PIN_3V} for {duration} seconds...")
        GPIO.output(PIN_3V, GPIO.HIGH)
        time.sleep(duration)
        GPIO.output(PIN_3V, GPIO.LOW)
        print("✅ Pin activation test completed successfully")
        return True
    except Exception as e:
        print(f"❌ Pin activation test failed: {e}")
        return False

def test_pin_state():
    """Test reading pin state"""
    try:
        state = GPIO.input(PIN_3V)
        print(f"📊 Current pin state: {'HIGH' if state else 'LOW'}")
        return True
    except Exception as e:
        print(f"❌ Failed to read pin state: {e}")
        return False

def cleanup():
    """Clean up GPIO settings"""
    try:
        GPIO.cleanup()
        print("🧹 GPIO cleanup completed")
    except Exception as e:
        print(f"⚠️  GPIO cleanup warning: {e}")

def main():
    """Main test function"""
    print("🌱 Bill's Aeroponics - GPIO Test Script")
    print("=" * 50)
    
    # Check if running on Raspberry Pi
    try:
        with open('/proc/cpuinfo', 'r') as f:
            if 'Raspberry Pi' not in f.read():
                print("⚠️  Warning: This script is designed for Raspberry Pi")
                print("   GPIO functionality may not work on other systems")
    except:
        print("⚠️  Could not verify system type")
    
    # Setup GPIO
    if not setup_gpio():
        sys.exit(1)
    
    # Test pin state reading
    if not test_pin_state():
        sys.exit(1)
    
    # Test pin activation
    print("\n🧪 Running pin activation tests...")
    
    # Test 1: Short activation
    if not test_pin_activation(1):
        sys.exit(1)
    
    time.sleep(1)
    
    # Test 2: Medium activation
    if not test_pin_activation(3):
        sys.exit(1)
    
    time.sleep(1)
    
    # Test 3: Longer activation
    if not test_pin_activation(5):
        sys.exit(1)
    
    print("\n✅ All GPIO tests passed!")
    print("🎉 Your hardware setup is working correctly")
    print("\n💡 You can now run the main application with:")
    print("   python3 app.py")
    print("   or")
    print("   ./start.sh")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n⏹️  Test interrupted by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
    finally:
        cleanup() 