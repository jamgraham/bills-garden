from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import RPi.GPIO as GPIO
import json
import os
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import threading
import time

app = Flask(__name__)
CORS(app)

# GPIO Configuration
PIN_3V = 18  # GPIO18 for 3V control
GPIO.setmode(GPIO.BCM)
GPIO.setup(PIN_3V, GPIO.OUT)
GPIO.output(PIN_3V, GPIO.LOW)

# Scheduler
scheduler = BackgroundScheduler()
scheduler.start()

# Data storage
SCHEDULE_FILE = 'schedule.json'

def load_schedule():
    """Load schedule from JSON file"""
    if os.path.exists(SCHEDULE_FILE):
        with open(SCHEDULE_FILE, 'r') as f:
            return json.load(f)
    return []

def save_schedule(schedule):
    """Save schedule to JSON file"""
    with open(SCHEDULE_FILE, 'w') as f:
        json.dump(schedule, f, indent=2)

def activate_pin(duration_seconds):
    """Activate 3V pin for specified duration"""
    try:
        GPIO.output(PIN_3V, GPIO.HIGH)
        time.sleep(duration_seconds)
        GPIO.output(PIN_3V, GPIO.LOW)
        print(f"Pin activated for {duration_seconds} seconds")
    except Exception as e:
        print(f"Error activating pin: {e}")

def schedule_job(schedule_id, cron_expression, duration_seconds):
    """Schedule a job to run at specified intervals"""
    def job_function():
        activate_pin(duration_seconds)
    
    # Parse cron expression (format: "minute hour * * *")
    parts = cron_expression.split()
    if len(parts) == 5:
        minute, hour = parts[0], parts[1]
        trigger = CronTrigger(minute=minute, hour=hour)
        scheduler.add_job(job_function, trigger=trigger, id=f"schedule_{schedule_id}")
        print(f"Scheduled job {schedule_id}: {cron_expression} for {duration_seconds}s")

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

@app.route('/api/schedule', methods=['GET'])
def get_schedule():
    """Get all schedules"""
    schedule = load_schedule()
    return jsonify(schedule)

@app.route('/api/schedule', methods=['POST'])
def create_schedule():
    """Create a new schedule"""
    data = request.json
    schedule = load_schedule()
    
    new_schedule = {
        'id': len(schedule) + 1,
        'name': data.get('name', 'Untitled'),
        'interval_minutes': data.get('interval_minutes', 60),
        'duration_seconds': data.get('duration_seconds', 30),
        'enabled': data.get('enabled', True),
        'created_at': datetime.now().isoformat()
    }
    
    schedule.append(new_schedule)
    save_schedule(schedule)
    
    # Schedule the job if enabled
    if new_schedule['enabled']:
        cron_expr = f"*/{new_schedule['interval_minutes']} * * * *"
        schedule_job(new_schedule['id'], cron_expr, new_schedule['duration_seconds'])
    
    return jsonify(new_schedule), 201

@app.route('/api/schedule/<int:schedule_id>', methods=['PUT'])
def update_schedule(schedule_id):
    """Update a schedule"""
    data = request.json
    schedule = load_schedule()
    
    for s in schedule:
        if s['id'] == schedule_id:
            s.update(data)
            save_schedule(schedule)
            
            # Remove existing job and reschedule if enabled
            try:
                scheduler.remove_job(f"schedule_{schedule_id}")
            except:
                pass
            
            if s.get('enabled', True):
                cron_expr = f"*/{s['interval_minutes']} * * * *"
                schedule_job(schedule_id, cron_expr, s['duration_seconds'])
            
            return jsonify(s)
    
    return jsonify({'error': 'Schedule not found'}), 404

@app.route('/api/schedule/<int:schedule_id>', methods=['DELETE'])
def delete_schedule(schedule_id):
    """Delete a schedule"""
    schedule = load_schedule()
    schedule = [s for s in schedule if s['id'] != schedule_id]
    save_schedule(schedule)
    
    # Remove scheduled job
    try:
        scheduler.remove_job(f"schedule_{schedule_id}")
    except:
        pass
    
    return jsonify({'message': 'Schedule deleted'})

@app.route('/api/pin/activate', methods=['POST'])
def activate_pin_now():
    """Activate pin immediately"""
    data = request.json
    duration = data.get('duration_seconds', 30)
    
    # Run in thread to avoid blocking
    thread = threading.Thread(target=activate_pin, args=(duration,))
    thread.start()
    
    return jsonify({'message': f'Pin activated for {duration} seconds'})

@app.route('/api/status')
def get_status():
    """Get system status"""
    return jsonify({
        'pin_state': GPIO.input(PIN_3V),
        'scheduler_running': scheduler.running,
        'active_jobs': len(scheduler.get_jobs())
    })

def load_existing_schedules():
    """Load and schedule existing schedules on startup"""
    schedule = load_schedule()
    for s in schedule:
        if s.get('enabled', True):
            cron_expr = f"*/{s['interval_minutes']} * * * *"
            schedule_job(s['id'], cron_expr, s['duration_seconds'])

if __name__ == '__main__':
    load_existing_schedules()
    app.run(host='0.0.0.0', port=5000, debug=True) 